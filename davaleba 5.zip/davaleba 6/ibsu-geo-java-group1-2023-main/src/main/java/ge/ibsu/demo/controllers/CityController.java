package ge.ibsu.demo.controllers;

import ge.ibsu.demo.entities.City;
import ge.ibsu.demo.repositories.CityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cities")
public class CityController {

    @Autowired
    private CityRepository cityRepository;

    @PostMapping
    public City addCity(@RequestBody City city) {
        return cityRepository.save(city);
    }

    @DeleteMapping("/{cityId}")
    public void removeCity(@PathVariable Long cityId) {
        cityRepository.deleteById(cityId);
    }
}

